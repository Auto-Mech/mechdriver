#$ -S /bin/bash 
#$ -l h_rt=240:00:00 
#$ -q modmol.q 
#$ -e job.err 
#$ -o job.out 
#$ -pe mpi 16
#$ -cwd 

hq worker start \
    --idle-timeout "1h" \
    --cpus "16" \
    --resource "mem=sum(57000)" \
#    --manager "pbs" \
    --on-server-lost "stop" \
    --time-limit "2h"
